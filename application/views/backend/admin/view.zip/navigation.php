<div class="sidebar-menu">
    <header class="logo-env" >
        <div class="logo" style="">
            <a href="<?php echo base_url(); ?>">
                <img src="uploads/logo.png"  style="max-height:60px;"/>
            </a>
        </div>

        <!-- logo collapse icon -->
        <div class="sidebar-collapse" style="">
            <a href="#" class="sidebar-collapse-icon with-animation">

                <i class="entypo-menu"></i>
            </a>
        </div>

        <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
        <div class="sidebar-mobile-menu visible-xs">
            <a href="#" class="with-animation">
                <i class="entypo-menu"></i>
            </a>
        </div>
    </header>

    <div style=""></div>	
    <ul id="main-menu" class="">
        <!-- add class "multiple-expanded" to allow multiple submenus to open -->
        <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->


        <!-- DASHBOARD -->
        <li class="<?php if ($page_name == 'dashboard') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/dashboard">
                <i class="entypo-gauge"></i>
                <span><?php echo get_phrase('dashboard'); ?></span>
            </a>
        </li>

        <li class="<?php
            if (
                $page_name == 'academic_year' ||
                $page_name == 'course' ||
                $page_name == 'year_wise_course' ||
                $page_name == 'batch' ||
                $page_name == 'sections' ||
                $page_name == 'subjects' ||
                $page_name == 'import_subjects' ||
                $page_name == 'section_allocation' ||
                $page_name == 'subject_allocation' ||
                $page_name == 'event_management' ||
                $page_name == 'assignment' ||
                $page_name == 'student_attendance' ||
                $page_name == 'question_category' ||
                $page_name == 'questions' ||
                $page_name == 'online_test' ||
                $page_name == 'view_result'
            )
                echo 'opened active';
            ?> ">
            <a href="#">
                <i class="entypo-suitcase"></i>
                <span><?php echo get_phrase('academic'); ?></span>
            </a>
            <ul>
                <li class="<?php
                if ($page_name == 'academic_year' ||
                    $page_name == 'course' ||
                    $page_name == 'year_wise_course' ||
                    $page_name == 'batch' ||
                    $page_name == 'sections' ||
                    $page_name == 'subjects' ||
                    $page_name == 'import_subjects' ||
                    $page_name == 'section_allocation' ||
                    $page_name == 'subject_allocation')
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('course_management'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'academic_year') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/academic_year">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('academic_year'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'course') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/course">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('course'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'year_wise_course') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/year_wise_course">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('year_wise_course'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'batch') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/batch">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('batch'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'sections') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/sections">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('sections'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'subjects') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/subjects">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('subjects'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'import_subjects') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/import_subjects">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('import_subjects'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'section_allocation') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/section_allocation">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('section_allocation'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'subject_allocation') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/subject_allocation">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('subject_allocation'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="<?php
                    if ($page_name == 'event_management' ||
                        $page_name == 'assignment')
                        echo 'opened active';
                    ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('academic'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'event_management') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/event_management">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('event_management'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'assignment') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/assignment">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('assignment'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if ($page_name == 'student_attendance')
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('student_attendance'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'student_attendance') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/student_attendance">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('student_attendance'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="<?php
                if ($page_name == 'question_category' ||
                    $page_name == 'questions' ||
                    $page_name == 'online_test' ||
                    $page_name == 'view_result')
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('online_test'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'question_category') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/question_category">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('question_category'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'questions') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/questions">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('questions'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'online_test') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/online_test">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('online_test'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'view_result') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/view_result">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('view_result'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>

        <li class="<?php
        if ($page_name == 'online_adm' ||
            $page_name == 'admission_applicants' ||
            $page_name == 'admission_letter' ||
            $page_name == 'source_type' ||
            $page_name == 'enquiry')
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-suitcase"></i>
                <span><?php echo get_phrase('admission'); ?></span>
            </a>
            <ul>
                <li class="<?php
                if ($page_name == 'online_adm' ||
                    $page_name == 'admission_applicants' ||
                    $page_name == 'admission_letter')
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('admission'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'online_adm') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/online_adm">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('online_admission'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'admission_applicants') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/admission_applicants">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('admission_applicants'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'admission_letter') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/admission_letter">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('admission_letter'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if ($page_name == 'source_type' ||
                    $page_name == 'enquiry')
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('leads'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'source_type') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/source_type">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('source_type'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'enquiry') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/enquiry">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('enquiry'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>

        <li class="<?php
        if (
            $page_name == 'add_employee' ||
            $page_name == 'manage_employee' ||
            $page_name == 'office_time' ||
            $page_name == 'attendance_fine' ||
            $page_name == 'monthly_attendance' ||
            $page_name == 'leave_head' ||
            $page_name == 'leave_entry' ||
            $page_name == 'leave_report'
        )
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-suitcase"></i>
                <span><?php echo get_phrase('HR_&_admin'); ?></span>
            </a>
            <ul>
                <li class="<?php
                if (
                    $page_name == 'add_employee' ||
                    $page_name == 'manage_employee'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('employee_profile'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'add_employee') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/add_employee">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('add_new_employee'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'manage_employee') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/manage_employee">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('profile_report'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if (
                    $page_name == 'office_time' ||
                    $page_name == 'attendance_fine'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('HR_setting'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'office_time') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/office_time">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('office_time'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'attendance_fine') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/attendance_fine">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('attendance_fine'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if ($page_name == 'monthly_attendance')
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('emp_attendance'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'monthly_attendance') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/monthly_attendance">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('monthly_attendance'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if (
                    $page_name == 'leave_head' ||
                    $page_name == 'leave_entry' ||
                    $page_name == 'leave_report'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('leave_management'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'leave_head') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/leave_head">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('leave_head'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'leave_entry') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/leave_entry">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('leave_entry'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'leave_report') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/leave_report">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('leave_report'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>

        <!-- STUDENT -->
        <li class="<?php
        if ($page_name == 'admission_category' ||
		        $page_name == 'add_student' ||
		        $page_name == 'manage_student' ||
                $page_name == 'import_student' ||
                $page_name == 'student_status' ||
                $page_name == 'promote_student')
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="fa fa-group"></i>
                <span><?php echo get_phrase('students'); ?></span>
            </a>
            <ul>
                 <li class="<?php if ($page_name == 'admission_category') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/admission_category">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('admission_category'); ?></span>
                    </a>
                </li>
                 <li class="<?php if ($page_name == 'add_student') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/add_student">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('add_student'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'manage_student') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/manage_student">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('manage_student'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'import_student') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/import_student">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('import_student'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'student_status') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/student_status">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('student_status'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'promote_student') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/promote_student">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('promote_student'); ?></span>
                    </a>
                </li>
            </ul>
        </li>

        <li class="<?php
        if (
            $page_name == 'add_new_subject' ||
            $page_name == 'add_grading_system' ||
            $page_name == 'exam_term_create' ||
            $page_name == 'subject_select' ||
            $page_name == 'marks_entry' ||
            $page_name == 'terms_trabulation_sheet' ||
            $page_name == 'final_trabulation_sheet' ||
            $page_name == 'term_progress_report' ||
            $page_name == 'final_mark_sheet'
        )
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-suitcase"></i>
                <span><?php echo get_phrase('exam_management'); ?></span>
            </a>
            <ul>
                <li class="<?php
                if (
                    $page_name == 'add_new_subject' ||
                    $page_name == 'add_grading_system' ||
                    $page_name == 'exam_term_create'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('exam_setting'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'add_new_subject') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/add_new_subject">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('add_new_subject'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'add_grading_system') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/add_grading_system">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('add_grading_system'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'exam_term_create') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/exam_term_create">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('exam_term_create'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if (
                    $page_name == 'subject_select'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('subject_select'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'subject_select') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/subject_select">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('subject_select'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if ($page_name == 'marks_entry')
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('marks_entry'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'marks_entry') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/marks_entry">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('marks_entry'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if (
                    $page_name == 'terms_trabulation_sheet' ||
                    $page_name == 'final_trabulation_sheet' ||
                    $page_name == 'term_progress_report' ||
                    $page_name == 'final_mark_sheet'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('exam_report'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'terms_trabulation_sheet') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/terms_trabulation_sheet">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('terms_trabulation_sheet'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'final_trabulation_sheet') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/final_trabulation_sheet">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('final_trabulation_sheet'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'term_progress_report') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/term_progress_report">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('term_progress_report'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'final_mark_sheet') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/final_mark_sheet">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('final_mark_sheet'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>

        <li style="display:none;" class="<?php
        if ($page_name == 'exam_group' ||
            $page_name == 'grade_level' ||
            $page_name == 'result_summary')
            echo 'opened active';
        ?> ">
            <a href="#">
                <span><i class="entypo-suitcase"></i> <?php echo get_phrase('exam_management'); ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'exam_group') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/exam_group">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('exam_group'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'grade_level') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/grade_level">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('grade_level'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'result_summary') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/result_summary">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('result_summary'); ?></span>
                    </a>
                </li>
            </ul>
        </li>

        <li class="<?php
        if ($page_name == 'bank_master' ||
            $page_name == 'fees_category' ||
            $page_name == 'fees_collect' ||
            $page_name == 'student_fees')
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-suitcase"></i>
                <span><?php echo get_phrase('student_fee'); ?></span>
            </a>
            <ul>
                <li class="<?php
                if ($page_name == 'bank_master' ||
                    $page_name == 'fees_category' ||
                    $page_name == 'fees_collect' ||
                    $page_name == 'student_fees')
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('fees'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'bank_master') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/bank_master">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('bank_master'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'fees_category') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/fees_category">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('fees_category'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'fees_collect') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/fees_collect">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('fees_collect'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'student_fees') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/student_fees">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('student_fees'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>

        <li class="<?php
        if ($page_name == 'week_days' ||
            $page_name == 'class_routine' ||
            $page_name == 'room_category' ||
            $page_name == 'room_master' ||
            $page_name == 'time_table')
            echo 'opened active';
        ?> ">
            <a href="#">
                <span><i class="entypo-suitcase"></i> <?php echo get_phrase('time_table'); ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'week_days') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/week_days">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('week_days'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'class_routine') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/class_routine">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('class_routine'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'room_category') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/room_category">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('room_category'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'room_master') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/room_master">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('room_master'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'time_table') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/time_table">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('time_table'); ?></span>
                    </a>
                </li>
            </ul>
        </li>

        <li class="<?php
        if (
            $page_name == 'pay_head' ||
            $page_name == 'employee_setup' ||
            $page_name == 'employee_view' ||
            $page_name == 'payroll_generate' ||
            $page_name == 'payroll_approve' ||
            $page_name == 'payroll_sheet'
        )
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-suitcase"></i>
                <span><?php echo get_phrase('payroll'); ?></span>
            </a>
            <ul>
                <li class="<?php
                if (
                    $page_name == 'pay_head' ||
                    $page_name == 'employee_setup' ||
                    $page_name == 'employee_view'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('payroll_settings'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'pay_head') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/pay_head">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('pay_head'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'employee_setup') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/employee_setup">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('employee_setup'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'employee_view') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/employee_view">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('employee_view'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if (
                    $page_name == 'payroll_generate'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('payroll_generate'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'payroll_generate') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/payroll_generate">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('payroll_generate'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if ($page_name == 'payroll_approve')
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('payroll_approve'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'payroll_approve') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/payroll_approve">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('payroll_approve'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if (
                    $page_name == 'payroll_sheet'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('report'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'payroll_sheet') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/payroll_sheet">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('payroll_sheet'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>

        <li style="display:none;" class="<?php if ($page_name == 'payroll_accounts') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/payroll_accounts">
                <i class="entypo-doc-text-inv"></i>
                <span><?php echo get_phrase('payroll_accounts'); ?></span>
            </a>
        </li>


        <li style="display:none;" class="<?php
        if ($page_name == 'student_add' ||
                $page_name == 'acd_session' ||
                $page_name == 'online_admission' ||
                $page_name == 'student_bulk_add' ||
                $page_name == 'student_information' ||
                $page_name == 'student_marksheet')
            echo 'opened active has-sub';
        ?> ">
            <a href="#">
                <i class="fa fa-group"></i>
                <span><?php echo get_phrase('student'); ?></span>
            </a>
            <ul>
                <!-- STUDENT ADMISSION -->
                
                 <li class="<?php if ($page_name == 'acd_session') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/acd_session">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('academic_session'); ?></span>
                    </a>
                </li>
                
                   
                 <li class="<?php if ($page_name == 'online_admission') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/online_admission">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('online_admission'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'student_add') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/student_add">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('admit_student'); ?></span>
                    </a>
                </li>

                <!-- STUDENT BULK ADMISSION -->
                <li class="<?php if ($page_name == 'student_bulk_add') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/student_bulk_add">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('admit_bulk_student'); ?></span>
                    </a>
                </li>

                <!-- STUDENT INFORMATION -->
                <li class="<?php if ($page_name == 'student_information') echo 'opened active'; ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('student_information'); ?></span>
                    </a>
                    <ul>
                        <?php
                        $classes = $this->db->get('class')->result_array();
                        foreach ($classes as $row):
                            ?>
                            <li class="<?php if ($page_name == 'student_information' && $class_id == $row['class_id']) echo 'active'; ?>">
                                <a href="<?php echo base_url(); ?>index.php?admin/student_information/<?php echo $row['class_id']; ?>">
                                    <span><?php echo get_phrase('class'); ?> <?php echo $row['name']; ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </li>

                <!-- STUDENT MARKSHEET -->
                <li class="<?php if ($page_name == 'student_marksheet') echo 'opened active'; ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('student_marksheet'); ?></span>
                    </a>
                    <ul>
                        <?php
                        $classes = $this->db->get('class')->result_array();
                        foreach ($classes as $row):
                            ?>
                            <li class="<?php if ($page_name == 'student_marksheet' && $class_id == $row['class_id']) echo 'active'; ?>">
                                <a href="<?php echo base_url(); ?>index.php?admin/student_marksheet/<?php echo $row['class_id']; ?>">
                                    <span><?php echo get_phrase('class'); ?> <?php echo $row['name']; ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </li>
            </ul>
        </li>

        <!-- TEACHER -->
        <li style="display:none;" class="<?php if ($page_name == 'teacher') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/teacher">
                <i class="entypo-users"></i>
                <span><?php echo get_phrase('teacher'); ?></span>
            </a>
        </li>

        <!-- PARENTS -->
        <li style="display:none;" class="<?php if ($page_name == 'parent') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/parent">
                <i class="entypo-user"></i>
                <span><?php echo get_phrase('parents'); ?></span>
            </a>
        </li>
        <li style="display:none;" class="<?php
        if ($page_name == 'class' ||
            $page_name == 'section')
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-flow-tree"></i>
                <span><?php echo get_phrase('class'); ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'class') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/classes">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('manage_classes'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'section') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/section">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('manage_sections'); ?></span>
                    </a>
                </li>
            </ul>
        </li>

        <!-- SUBJECT -->
        <li style="display: none;" class="<?php if ($page_name == 'subject') echo 'opened active'; ?> ">
            <a href="#">
                <i class="entypo-docs"></i>
                <span><?php echo get_phrase('subject'); ?></span>
            </a>
            <ul>
                <?php
                $classes = $this->db->get('class')->result_array();
                foreach ($classes as $row):
                    ?>
                    <li class="<?php if ($page_name == 'subject' && $class_id == $row['class_id']) echo 'active'; ?>">
                        <a href="<?php echo base_url(); ?>index.php?admin/subject/<?php echo $row['class_id']; ?>">
                            <span><?php echo get_phrase('class'); ?> <?php echo $row['name']; ?></span>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </li>

        <!-- CLASS ROUTINE -->
        <!--<li class="<?php /*if ($page_name == 'class_routine') echo 'active'; */?> ">
            <a href="<?php /*echo base_url(); */?>index.php?admin/class_routine">
                <i class="entypo-target"></i>
                <span><?php /*echo get_phrase('class_routine'); */?></span>
            </a>
        </li>
        -->
        <!-- DAILY ATTENDANCE -->
        <li style="display:none;" class="<?php if ($page_name == 'manage_attendance') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/manage_attendance/<?php echo date("d/m/Y"); ?>">
                <i class="entypo-chart-area"></i>
                <span><?php echo get_phrase('daily_attendance'); ?></span>
            </a>

        </li>

        <!-- EXAMS -->
        <li style="display:none;" class="<?php
        if ($page_name == 'exam' ||
                $page_name == 'grade' ||
                $page_name == 'marks' ||
                    $page_name == 'exam_marks_sms')
                        echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-graduation-cap"></i>
                <span><?php echo get_phrase('exam'); ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'exam') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/exam">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('exam_list'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'grade') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/grade">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('exam_grades'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'marks') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/marks">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('manage_marks'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'exam_marks_sms') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/exam_marks_sms">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('send_marks_by_sms'); ?></span>
                    </a>
                </li>
            </ul>
        </li>

        <!-- PAYMENT -->
        <li style="display:none;" class="<?php if ($page_name == 'invoice') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/invoice">
                <i class="entypo-credit-card"></i>
                <span><?php echo get_phrase('payment'); ?></span>
            </a>
        </li>

        <!-- ACCOUNTING -->
        <li style="display:none;" class="<?php
        if ($page_name == 'income' ||
                $page_name == 'expense' ||
                    $page_name == 'expense_category')
                        echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-suitcase"></i>
                <span><?php echo get_phrase('accounting'); ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'income') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/income">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('income'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'expense') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/expense">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('expense'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'expense_category') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/expense_category">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('expense_category'); ?></span>
                    </a>
                </li>
            </ul>
        </li>

        <!-- LIBRARY -->
        <li style="display:none;" class="<?php if ($page_name == 'book') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/book">
                <i class="entypo-book"></i>
                <span><?php echo get_phrase('library'); ?></span>
            </a>
        </li>

        <!-- TRANSPORT -->
        <li style="display:none;" class="<?php if ($page_name == 'transport') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/transport">
                <i class="entypo-location"></i>
                <span><?php echo get_phrase('transport'); ?></span>
            </a>
        </li>

        <li class="<?php
        if ($page_name == 'transport' ||
            $page_name == 'vehicles')
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-suitcase"></i>
                <span><?php echo get_phrase('transport'); ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'transport') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/transport">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('transport'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'vehicles') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/vehicles">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('vehicles'); ?></span>
                    </a>
                </li>
            </ul>
        </li>

        <li class="<?php
        if ($page_name == 'dormitory' ||
            $page_name == 'rooms' ||
            $page_name == 'rooms_allocation' ||
            $page_name == 'fee_collection')
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-suitcase"></i>
                <span><?php echo get_phrase('dormitory'); ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'dormitory') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/dormitory">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('dormitory'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'rooms') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/rooms">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('rooms'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'rooms_allocation') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/rooms_allocation">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('rooms_allocation'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'fee_collection') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/fee_collection">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('fee_collection'); ?></span>
                    </a>
                </li>
            </ul>
        </li>
        <!-- DORMITORY -->
        <li style="display:none;" class="<?php if ($page_name == 'dormitory') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/dormitory">
                <i class="entypo-home"></i>
                <span><?php echo get_phrase('dormitory'); ?></span>
            </a>
        </li>

        <!-- NOTICEBOARD -->
        <li style="display:;" class="<?php if ($page_name == 'noticeboard') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/noticeboard">
                <i class="entypo-doc-text-inv"></i>
                <span><?php echo get_phrase('noticeboard'); ?></span>
            </a>
        </li>

        <li class="<?php
        if (
            $page_name == 'add_product_type' ||
            $page_name == 'add_product_category' ||
            $page_name == 'add_product' ||
            $page_name == 'product_in' ||
            $page_name == 'product_out' ||
            $page_name == 'stock_info' ||
            $page_name == 'product_in_report' ||
            $page_name == 'product_out_report' ||
            $page_name == 'stock_information'
        )
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-suitcase"></i>
                <span><?php echo get_phrase('store_management'); ?></span>
            </a>
            <ul>
                <li class="<?php
                if (
                    $page_name == 'add_product_type' ||
                    $page_name == 'add_product_category' ||
                    $page_name == 'add_product'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('store_setting'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'add_product_type') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/add_product_type">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('add_product_type'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'add_product_category') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/add_product_category">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('add_product_category'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'add_product') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/add_product">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('add_product'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if (
                    $page_name == 'product_in' ||
                    $page_name == 'product_out' ||
                    $page_name == 'stock_info'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('inventory'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'product_in') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/product_in">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('product_in'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'product_out') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/product_out">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('product_out'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'stock_info') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/stock_info">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('stock_info'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="<?php
                if (
                    $page_name == 'product_in_report' ||
                    $page_name == 'product_out_report' ||
                    $page_name == 'stock_information'
                )
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('inventory_report'); ?></span>
                    </a>
                    <ul>
                        <li class="<?php if ($page_name == 'product_in_report') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/product_in_report">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('product_in_report'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'product_out_report') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/product_out_report">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('product_out_report'); ?></span>
                            </a>
                        </li>
                        <li class="<?php if ($page_name == 'stock_information') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>index.php?admin/stock_information">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('stock_information'); ?></span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>

        <li style="display:none;" class="<?php if ($page_name == 'store_management') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/store_management">
                <i class="entypo-doc-text-inv"></i>
                <span><?php echo get_phrase('store_management'); ?></span>
            </a>
        </li>

        <!-- MESSAGE -->
        <li style="display:;" class="<?php if ($page_name == 'message') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/message">
                <i class="entypo-mail"></i>
                <span><?php echo get_phrase('message'); ?></span>
            </a>
        </li>

        <!-- SETTINGS -->
        <li style="display:none;" class="<?php
        if ($page_name == 'system_settings' ||
                $page_name == 'manage_language' ||
                    $page_name == 'sms_settings')
                        echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-lifebuoy"></i>
                <span><?php echo get_phrase('settings'); ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'system_settings') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/system_settings">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('general_settings'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'sms_settings') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/sms_settings">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('sms_settings'); ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'manage_language') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>index.php?admin/manage_language">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('language_settings'); ?></span>
                    </a>
                </li>
            </ul>
        </li>
        <li class="<?php if ($page_name == 'manage_profile') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>index.php?admin/manage_profile">
                <i class="entypo-lock"></i>
                <span><?php echo get_phrase('my_account'); ?></span>
            </a>
        </li>

    </ul>

</div>