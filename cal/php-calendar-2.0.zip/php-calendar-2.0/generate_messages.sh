#! /bin/sh
xgettext --language=PHP --keyword="__" --keyword="__p:1c,2" *.php includes/*.php
