functionValidation(){
		if(result < 4.5)
    {
        document.getElementById("onclick() function name").innerHTML="You are not eligible for the admission.";

    }
}